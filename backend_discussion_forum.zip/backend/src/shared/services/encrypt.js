import bcrypt from 'bcrypt';
const SALT = 10;
export const passwordHashing = (plainPassword)=>{
    return bcrypt.hashSync(plainPassword, SALT);
}

export const compareHash = (plainPassword, dbHashPassword)=>{
    return bcrypt.compareSync(plainPassword, dbHashPassword);
}

