import jwt from 'jsonwebtoken';//secret for other not te be same
export const genearteToken=()=>{
    const SECRET=process.env.SECRET;
    jwt.sign({email:user.email, name:user.name},SECRET,{expiresIn:'1h'}); //paylaod is for which data we are binding it.
}

export const verifyToken=(token)=>{
    try{
    const decoded=jwt.verify(token.SECRET);
   return decoded && decoded.email;
} catch(err){
    console.log('Invalid Token',err);
    throw err;
}

     
    

}