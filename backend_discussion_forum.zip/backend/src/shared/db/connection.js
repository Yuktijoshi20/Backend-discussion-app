import mongoose from 'mongoose';
export function createConnection(){
const URL = process.env.DB_URL;
return mongoose.connect(URL);
}
