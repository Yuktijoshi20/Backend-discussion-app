
import express from 'express';
import { userValidationSchema } from '../validations/user-validation.js';
import { register,login } from '../controller/user-controller.js';
import { validate } from '../../../shared/middleware/validation-middleware.js';
export const userRoute = express.Router();
userRoute.post('/register',validate(userValidationSchema),register);
userRoute.post('/login',login);
/*
*/