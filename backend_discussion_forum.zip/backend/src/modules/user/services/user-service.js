import {UserModel} from '../models/user-schema.js';
import { compareHash , passwordHashing} from '../../../shared/services/encrypt.js';
//DB Crud operations
export const userService={
    async register(user){
        try{
            user.password=passwordHashing(user.password);
            const doc=await UserModel.create(user);
            return doc;
        }catch(err){
            console.log('Unable',err);
            throw err;
        }
    },
    async login(user){
       const doc=await UserModel.findOne({'email':user.email}).lean().exec(); //lean-remove the extra data make it fit(patla). //When the record is found it stops , find()-linear search
            //pojo -plain javascript object like lean().
            if(doc && doc.email){
                if(compareHash(user.password,doc.password)){
                    const token=generateToken(user);
                    return {message:messages['login-success']+doc.name, success:true,token:token};
                }else{
                    return {message:'Invalid Userid or Password', success: false}
                }
            }else{
                return {message:'Invalid Userid or Password', success: false}
            }
    }
}