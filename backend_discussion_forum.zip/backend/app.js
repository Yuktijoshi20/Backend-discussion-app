import express from 'express';
import { createConnection } from './src/shared/db/connection.js';
import dotenv from 'dotenv';
import morgan from 'morgan';

import { userRoute } from './src/modules/user/routes/user-route.js';
import { errorHandler } from './src/shared/middleware/error-handler.js';
import cors from'cors';

process.on('uncaughtException',err=>{
    console.log('some issue arrives',err);
})
const app=express();
app.use(cors());
const promise=createConnection();
dotenv.config();
app.use('/',userRoute);//it is a middle ware that has three arg req,resp,next.
app.use(express.json);
//attach error handler
app.use(errorHandler);
app.use(morgan('combined',{stream:serverLogStream()}))
promise.then(data=>{
    console.log('DB connection done');
    app.listen(1234,err=>{
        if(err){
            console.log('Server crash',err);
        }
        else{
            console.log('Server up and running');
        }
    })
}).catch(err=>{
    console.log('Error.in DB connection',err);
})
